from .mouse.__main__    import mouse
from .keyboard.__main__ import keyboard
from .joystick.__main__ import joysticks
