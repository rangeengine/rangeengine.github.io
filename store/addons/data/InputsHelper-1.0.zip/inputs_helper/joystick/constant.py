# deadzone
DEFAULT = 5000
MIN     = 0
MAX     = 65536
