from .constant import DEFAULT

analog = {
    "Left"  : [-DEFAULT, DEFAULT, -DEFAULT, DEFAULT],    
    "Right" : [-DEFAULT, DEFAULT, -DEFAULT, DEFAULT],
}

trigger = {
    "Left"  : DEFAULT,
    "Right" : DEFAULT,
}
