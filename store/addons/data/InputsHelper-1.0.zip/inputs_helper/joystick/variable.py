# a list containing the active buttons
activeButtons = []